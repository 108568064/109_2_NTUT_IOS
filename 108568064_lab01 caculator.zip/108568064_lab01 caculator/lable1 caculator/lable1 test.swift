//
//  ViewController.swift
//  lable1 caculator
//
//  Created by 林晏論 on 2021/3/8.
//

import UIKit


enum OperationType{
    case add
    case subtract
    case multiply
    case divide
    case none
}
enum testcase{
    case add
    case subtract
    case multiply
    case divide
    case none
}
class ViewController: UIViewController {
    var numberOnScreen:Double = 0
    var previousNumber:Double = 0
    var preformingMath = false
    var opertion:OperationType = .none
    var startNew = true
    var test:Double = 1
    
    
    override var preferredStatusBarStyle:
        UIStatusBarStyle{
        return .lightContent
    }
    
    
    
    @IBOutlet weak var lableresult: UILabel!
    @IBOutlet weak var process: UILabel!
    
    
    @IBAction func add(_ sender: UIButton) {
        lableresult.text = ""
        preformingMath = true
        if test==1 {
            previousNumber = numberOnScreen
            test=0
        }
        else
        {
            switch opertion {
            case .add:
                previousNumber += numberOnScreen
            case .subtract:
                previousNumber -= numberOnScreen
            case .multiply:
                previousNumber *= numberOnScreen
            case .divide:
                previousNumber /= numberOnScreen
            case .none:
               previousNumber = 0
            
            }
        }
        
        process.text = "\(process.text!)" + "\(numberOnScreen)" + "+"
        opertion = .add
    }
    
    @IBAction func subtract(_ sender: UIButton) {
        lableresult.text = ""
        
        preformingMath = true
        if test==1 {
            previousNumber = numberOnScreen
            test=0
        }
        else
        {
            switch opertion {
            case .add:
                previousNumber += numberOnScreen
            case .subtract:
                previousNumber -= numberOnScreen
            case .multiply:
                previousNumber *= numberOnScreen
            case .divide:
                previousNumber /= numberOnScreen
            case .none:
               previousNumber = 0
                

            }
        }
        process.text = "\(process.text!)" + "\(numberOnScreen)" + "-"
        opertion = .subtract
    }
    
   
    
    @IBAction func multiply(_ sender: UIButton) {
        lableresult.text = ""
       
        preformingMath = true
        if test==1 {
            previousNumber = numberOnScreen
            test=0
        }
        else
        {
            switch opertion {
            case .add:
                previousNumber += numberOnScreen
            case .subtract:
                previousNumber -= numberOnScreen
            case .multiply:
                previousNumber *= numberOnScreen
            case .divide:
                previousNumber /= numberOnScreen
            case .none:
               previousNumber = 0
                

            }
        }
        process.text = "\(process.text!)" + "\(numberOnScreen)" + "*"
        opertion = .multiply
    }
    
    
    @IBAction func divide(_ sender: UIButton) {
        lableresult.text = ""
        
        preformingMath = true
        if test==1 {
            previousNumber = numberOnScreen
            test=0
        }
        else
        {
            switch opertion {
            case .add:
                previousNumber += numberOnScreen
            case .subtract:
                previousNumber -= numberOnScreen
            case .multiply:
                previousNumber *= numberOnScreen
            case .divide:
                previousNumber /= numberOnScreen
            case .none:
               previousNumber = 0
                

            }
        }
        process.text = "\(process.text!)" + "\(numberOnScreen)" + "/"
        opertion = .divide
    }
    
    
    
    @IBAction func answer(_ sender: UIButton) {
        if preformingMath == true{
            switch opertion{
            
            case .add:
            process.text = "\(process.text!)" + "\(numberOnScreen)" + " = \(previousNumber + numberOnScreen)"
            lableresult.text = "\(previousNumber + numberOnScreen)"
                
                
            case .subtract:
            process.text = "\(process.text!)" + "\(numberOnScreen)" + " = \(previousNumber - numberOnScreen)"
            lableresult.text = "\(previousNumber - numberOnScreen)"
               
                
            case .multiply:
            process.text = "\(previousNumber)" + " *\(numberOnScreen)" + " = \(previousNumber * numberOnScreen)"
            lableresult.text = "\(previousNumber * numberOnScreen)"
                
                
            case .divide:
            process.text = "\(previousNumber)" + " /\(numberOnScreen)" + " = \(previousNumber / numberOnScreen)"
            lableresult.text = "\(previousNumber / numberOnScreen)"
                
                
            case .none:
            lableresult.text = "0"
                
            }
            preformingMath = false
                  }
    }
    
    
    
    @IBAction func numbers(_ sender: UIButton) {
     let inputNumber = sender.tag - 1
        if lableresult.text != nil{
            if lableresult.text == "0"{
                lableresult.text = "\(inputNumber)"
            }else{
                lableresult.text = lableresult.text! + "\(inputNumber)"
            }
                
                
        }
        numberOnScreen = Double(lableresult.text!) ?? 0
    }
    
    
    @IBAction func clear(_ sender: UIButton) {
        lableresult.text = "0"
        process.text = ""
        numberOnScreen = 0
        previousNumber = 0
        preformingMath = false
        opertion = .none
        startNew = true
        test=1
    }
    
    
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

