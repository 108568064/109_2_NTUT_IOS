//
//  songview.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/5/10.
//

import SwiftUI

struct songview: View {
    @Binding var ShowFivethPage: Bool
    var body: some View {
        VStack {
            HStack {
                Image("擱淺")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 100)
                    .clipped()
                VStack(alignment: .leading) {
                    Text("擱淺")
                    Text("周杰倫")}
                Spacer()
                
            }
            HStack{
                
                Image("七里香")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 100)
                    .clipped()
                VStack(alignment: .leading) {
                    Text("七里香")
                    Text("周杰倫")}
                Spacer()
                
            }
            Spacer()
        }
        .overlay(
                Button(action: {
                    ShowFivethPage = false
                }, label: {
                    Image(systemName: "xmark.circle.fill")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .padding()
                }), alignment: .topTrailing)
        
        
    }
    
}

struct songview_Previews: PreviewProvider {
    static var previews: some View {
        songview(ShowFivethPage: .constant(true))
            .previewLayout(.sizeThatFits)
    }
}
