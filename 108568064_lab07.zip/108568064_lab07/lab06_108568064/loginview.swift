//
//  loginview.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/5/3.
//

import SwiftUI

struct loginview: View {
    
    @Binding var ShowSecondPage: Bool
    @State private var brightnessAmount: Double = 0
    @State private var grayAmount: Double = 0
    
    var body: some View {
       VStack {
            VStack {
                
                Image("iphone122")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 400, height: 400)
                    .brightness(brightnessAmount)
                    .grayscale(0)
            
               Text("亮度調整")

                Slider(value: $brightnessAmount, in: 0...1)
                Text("灰度調整")
                Slider(value: $grayAmount, in: 0...1)

            
            
            
            //            Text("更小、更快、更清晰")
            //                .frame(width: 500, height: 500)
            }
        }
        .padding()
        .overlay(
            Button(action: {
                ShowSecondPage = false
            }, label: {
                Image(systemName: "xmark.circle.fill")
                    .resizable()
                    .frame(width: 50, height: 50)
                    .padding()
            }), alignment: .topTrailing)
        
    }
}

struct loginview_Previews: PreviewProvider {
    static var previews: some View {
        loginview(ShowSecondPage: .constant(true))
    }
}
