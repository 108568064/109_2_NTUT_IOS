//
//  lab09App.swift
//  lab09
//
//  Created by 林晏論 on 2021/5/19.
//

import SwiftUI

@main
struct lab09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
