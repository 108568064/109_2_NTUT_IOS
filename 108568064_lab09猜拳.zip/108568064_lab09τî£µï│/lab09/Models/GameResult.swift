//
//  GameResult.swift
//  lab09
//
//  Created by 林晏論 on 2021/5/19.
//

import Foundation

enum GameResult {
    case win
    case lose
}
