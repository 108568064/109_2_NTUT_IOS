//
//  SongList.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/5/10.
//

import SwiftUI

struct SongList: View {
    let songs = [
        Song(name: "擱淺", singer: "周杰倫"),
        Song(name: "七里香", singer: "周杰倫")
    ]
    var body: some View {
        
            NavigationView {
                List(songs) { song in
                    
                    NavigationLink(
                        destination: SongDetail(song: song),
                        label: {
                            SongRow(song: song)
                        })
                    
                }
                .navigationTitle("Songs")
            }
    }
}

struct SongList_Previews: PreviewProvider {
    static var previews: some View {
        SongList()
    }
}
