//
//  Song.swift
//  lab10
//
//  Created by 林晏論 on 2021/5/26.
//

import FirebaseFirestoreSwift

struct Song: Codable, Identifiable {
    @DocumentID var id: String?
    let name: String
    let singer: String
    let rate: String
   
}

