//
//  Song.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/5/10.
//

import Foundation
struct Song: Identifiable {
    let id = UUID()
    let name: String
    let singer: String
}
