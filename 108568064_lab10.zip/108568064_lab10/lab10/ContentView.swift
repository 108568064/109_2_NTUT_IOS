//
//  ContentView.swift
//  lab10
//
//  Created by 林晏論 on 2021/5/26.
//

import SwiftUI
import FirebaseFirestore
import FirebaseStorageSwift

struct ContentView: View {
    @State var todoapp = [TodoApp]()
    @State var songs = [Song]()
    @State private var snackTime = Date()
    @State private var tapping = ""
    @State private var showalert = false
    
    func createSong() {
        let db = Firestore.firestore()
        
        let song = Song(name: "陪你很久很久", singer: "小球", rate: "5")
        do {
            try db.collection("songs").document("陪你很久很久").setData(from: song)
        } catch {
            print(error)
        }
    }
    
    func fetchSongs(){
        let db = Firestore.firestore()
        db.collection("songs").getDocuments { snapshot, error in
            
            guard let snapshot = snapshot else { return }
            
            songs = snapshot.documents.compactMap { documentSnapshot in try? documentSnapshot.data(as: Song.self)
            }
            print(songs)
        }
    }
    
    var body: some View {
        
        
        VStack (alignment: .trailing, spacing: 20)
        {
            
            VStack{
                VStack{
                    HStack{
                        Text("名稱")
                        TextField("請輸入名稱", text:$tapping)
                    }
                }
            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
            VStack{
                HStack{
                    Text("是否完成")
                    TextField("輸入是否完成", text:$tapping)
                    
                }
            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
            
            DatePicker("到期時間", selection: $snackTime)
            
            VStack{
                Button(action: {
                    showalert = true
                }, label: {
                    Text("送出表單")
                        .padding()
                })
                .onAppear(perform: {
                    fetchSongs()
                })
                
            }
            VStack {
                Text("------------------------------------------------------")
            }
            
            VStack{
                HStack{
                    List(songs) { song in
                        Text("名稱")
                        Text(song.name)
                        
                    }
                }
            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
            VStack{
                HStack{
                    List(songs) { song in
                        Text("是否完成")
                        Text(song.singer)
                        
                        
                    }
                }
            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
            VStack{
                HStack{
                    List(songs) { song in
                        Text("到期時間")
                        Text(song.rate)
                        
                        
                    }
                }
            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
            
            VStack{
                Button(action: {
                    showalert = true
                }, label: {
                    Text("讀取數據")
                        .padding()
                })
                .onAppear(perform: {
                    fetchSongs()
                })
                
            }
            
        }
    }
    
    //    @State var todoapp = [TodoApp]()
    //    @State private var snackTime = Date()
    //    @State private var tapping = ""
    //
    //    func fetchtodoapp(){
    //        let db = Firestore.firestore()
    //        db.collection("todoapp").getDocuments { snapshot, error in
    //
    //            guard let snapshot = snapshot else { return }
    //
    //            todoapp = snapshot.documents.compactMap { documentSnapshot in try? documentSnapshot.data(as: TodoApp.self)
    //            }
    //            print(todoapp)
    //        }
    //    }
    //
    //    var body: some View {
    //        VStack {
    //            DatePicker("傳送時間", selection: $snackTime)
    //        VStack{
    //            TextField("打字", text:$tapping)
    //        }
    //        .textFieldStyle(RoundedBorderTextFieldStyle())
    //        .padding()
    //
    //        VStack{ List(todoapp) { todoapp in
    //
    //                Text(todoapp.name)
    //                Text(todoapp.finish)
    //                Text(todoapp.time)
    //            }
    //
    //        }}
    //        .onAppear(perform: {
    //            fetchtodoapp()
    //        })
    //    }
    //}
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
