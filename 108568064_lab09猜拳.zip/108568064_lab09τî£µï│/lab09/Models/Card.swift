//
//  Card.swift
//  lab09
//
//  Created by 林晏論 on 2021/5/19.
//

import Foundation


struct Card {

let suit: Suit
//let rank: Rank

enum Suit: String, CaseIterable
{
//    case spades = "♠"
//    case hearts = "♥"
//    case diamonds = "♦"
//    case clubs = "♣"
    case scissors = "✌️"
    case stone = "👊"
    case paper = "🖐"
}
//enum Rank: String, CaseIterable {
//
//    case ace = "A"
//    case two = "2"
//    case three = "3"
//    case four = "4"
//    case five = "5"
//    case six = "6"
//    case seven = "7"
//    case eight = "8"
//    case nine = "9"
//    case ten = "10"
//    case jack = "J"
//    case queen = "Q"
//    case king = "K"
//
//}

}
