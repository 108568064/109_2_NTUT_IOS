//
//  SongDetail.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/5/10.
//

import SwiftUI

struct SongDetail: View {
    
    let song: Song
    
    var body: some View {
        Image(song.name)
            .resizable()
            .scaledToFit()
        
    }
}

struct SongDetail_Previews: PreviewProvider {
    static var previews: some View {
        SongDetail(song: Song(name: "七里香", singer: "周杰倫"))
    }
}
