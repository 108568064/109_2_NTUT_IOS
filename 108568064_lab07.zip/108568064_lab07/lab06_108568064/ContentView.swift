//
//  ContentView.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/4/28.
//

import SwiftUI

struct ContentView: View {
    
    @State private var number1 = 1
    @State private var number2 = 2
    @State private var number3 = 3
    @State private var guessNum = ""
    @State private var gold = 1000
    @State private var anser = "猜測中"
    @State private var ShowSecondPage = false
    @State private var ShowThirdPage = false
    @State private var ShowFourthPage = false
    @State private var ShowFivethPage = false
    var body: some View {
        VStack{
            VStack {
                Image("iphone12")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 400)
                
                
//                Text("Iphone12").frame(width: 200, height:100, alignment: .center)
//                    .font(.title)
            }
//            HStack {
//                Image(systemName:
//                        "die.face.\(number2)")
//                    .resizable()
//                    .scaledToFit()
//                    .frame(width: 100, height: 100)
//
//                Text("骰子2數字:\(number2)").frame(width: 200, height:100, alignment: .center)
//                    .font(.title)
//
//            }
//            HStack {
//                Image(systemName:
//                        "die.face.\(number3)")
//                    .resizable()
//                    .scaledToFit()
//                    .frame(width: 100, height: 100)
//
//                Text("骰子3數字:\(number3)").frame(width: 200, height:100, alignment: .center)
//                    .font(.title)
//            }
            
//            Button(action: {
//                number1 = Int.random(in: 1...6)
//                number2 = Int.random(in: 1...6)
//                number3 = Int.random(in: 1...6)
//
//                if Int(guessNum) == number1 + number2 + number3
//                {
//                    gold += 100
//                    anser = "猜對了,金錢+100"
//                }
//                else
//                {
//                    gold -= 100
//                    anser = "猜錯了,金錢-100"
//                }
//
//            }, label: {
//                Text("play")
//                    .font(.largeTitle)
//            })
            
            Button(action: {
                ShowSecondPage = true
            }, label: {
                Text("show second page").frame(width: 200, height:50)
            })
            .sheet(isPresented: $ShowSecondPage, content: {
                loginview(ShowSecondPage: $ShowSecondPage)
            })
            .padding()
            .border(Color.blue, width: 3)
            Spacer()
            
            
            
            Button(action: {
                ShowThirdPage = true
            }, label: {
                Text("show third page").frame(width: 200, height:50)
            })
            .sheet(isPresented: $ShowThirdPage, content: {
                thirdview(ShowThirdPage: $ShowThirdPage)
            })
            .padding()
            .border(Color.blue, width: 3)
            Spacer()
            
            Button(action: {
                ShowFourthPage = true
            }, label: {
                Text("show fourth page").frame(width: 200, height:50)
            })
            .sheet(isPresented: $ShowFourthPage, content: {
                bindingview(ShowFourthPage: $ShowFourthPage)
            })
            .padding()
            .border(Color.blue, width: 3)
            Spacer()
            
            Button(action: {
                ShowFivethPage = true
            }, label: {
                Text("show fiveth page").frame(width: 200, height:50)
            })
            .sheet(isPresented: $ShowFivethPage, content: {
                songview(ShowFivethPage: $ShowFivethPage)
            })
            .padding()
            .border(Color.blue, width: 3)
            Spacer()
            
//            HStack {
//                TextField("請輸入猜測總和", text: $guessNum)
//                    .textFieldStyle(RoundedBorderTextFieldStyle())
//                    .keyboardType(.numberPad)
//                    .padding()
//
//            }
            
//            Label("猜測結果:\(anser)", systemImage: "60.circle")
//
//            Label("剩餘金額:\(gold)", systemImage: "60.circle")
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


