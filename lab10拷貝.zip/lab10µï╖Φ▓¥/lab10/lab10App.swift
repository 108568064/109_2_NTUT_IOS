//
//  lab10App.swift
//  lab10
//
//  Created by 林晏論 on 2021/5/26.
//

import SwiftUI

@main
struct lab10App: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
