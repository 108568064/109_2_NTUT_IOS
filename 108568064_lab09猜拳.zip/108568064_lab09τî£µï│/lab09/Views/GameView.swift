//
//  GameView.swift
//  lab09
//
//  Created by 林晏論 on 2021/5/19.
//

import SwiftUI

struct GameView: View {
    
    @StateObject var gameViewModel = GameViewModel()

var body: some View {
    VStack {
        HStack(spacing: 100.0) {
            VStack {
                Text("player")
//                Text(gameViewModel.playerCard?.rank.rawValue ?? "")
                Text(gameViewModel.playerCard?.suit.rawValue ?? "")
            }
            VStack {
                Text("computer")
//                Text(gameViewModel.computerCard?.rank.rawValue ?? "")
                Text(gameViewModel.computerCard?.suit.rawValue ?? "")
            }
        }
        
        if let result = gameViewModel.result {
            Text(gameViewModel.result == .win ? "Win🍔" : "lose🥲" )
                .font(.system(size: 100))
        }
        Button(action: {
            gameViewModel.play()
        }, label: {
            Text("Play")
        })
    }
    .font(.largeTitle)
}
}
struct GameView_Previews: PreviewProvider {
    static var previews: some View {
        GameView()
    }
}

