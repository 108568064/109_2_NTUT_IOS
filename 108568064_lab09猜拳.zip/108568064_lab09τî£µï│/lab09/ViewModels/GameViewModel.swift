//
//  GameViewModel.swift
//  lab09
//
//  Created by 林晏論 on 2021/5/19.
//

import Foundation

class GameViewModel: ObservableObject {
    @Published var playerCard: Card?
    @Published var computerCard: Card?
    @Published var result: GameResult?
    
    var cards: [Card] = {
        var cards = [Card]()
        for suit in Card.Suit.allCases
//        {
//            for rank in Card.Rank.allCases
            {
                let card = Card(suit: suit)
                cards.append(card)
            }
//        }
        return cards
    }()
    
    func play() {
        cards.shuffle()
        playerCard = cards[0]
        computerCard = cards[1]
        result = checkResult()
    }
    func checkResult() -> GameResult {
        
        let playerSuitIndex = Card.Suit.allCases.firstIndex(of: playerCard!.suit)!
        let computerSuitIndex = Card.Suit.allCases.firstIndex(of: computerCard!.suit)!
        if playerSuitIndex > computerSuitIndex {
            return .win
        }else {
            return .lose
        }
    }
    
}
