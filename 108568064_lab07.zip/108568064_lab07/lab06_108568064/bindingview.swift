//
//  bindingview.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/5/10.
//

import SwiftUI

struct bindingview: View {
    @Binding var ShowFourthPage: Bool
    @State var isRain = true
    var body: some View {
        VStack {
            
            Image(systemName: isRain ? "cloud.rain.fill" : "sun.max.fill")
                .resizable()
                .frame(width: 100, height: 100)
            Text( isRain ? "下雨好怕" : "放晴好爽")
                Toggle(isOn: $isRain, label: {
                Text("有雨嗎？")
                })
                
            
        }
        .overlay(
                Button(action: {
                    ShowFourthPage = false
                }, label: {
                    Image(systemName: "xmark.circle.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                        .padding(50)
                }), alignment: .topTrailing)
    
    }
}

struct bindingview_Previews: PreviewProvider {
    static var previews: some View {
        bindingview(ShowFourthPage: .constant(true))
    }
}
