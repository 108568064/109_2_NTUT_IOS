//
//  lab06_108568064App.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/4/28.
//

import SwiftUI

@main
struct lab06_108568064App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
