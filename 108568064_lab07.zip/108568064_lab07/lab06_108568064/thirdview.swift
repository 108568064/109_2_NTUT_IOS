//
//  thirdview.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/5/5.
//

import SwiftUI

struct thirdview: View {
    
    @Binding var ShowThirdPage: Bool
    
    var body: some View {
        
            VStack {
                
                    Image("iphone121")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 400, height: 400)
              
                Text("iPhone 12超快速，超越新境界。具備 5G 網速、智慧型手機最快速的 A14 仿生晶片、全面延伸的 OLED 顯示器，擁有四倍耐摔優異表現的超瓷晶盾，還能讓你在每個相機上使用「夜間」模式。iPhone 12 樣樣俱全，並以兩款完美尺寸呈現。")
                
            }
            .overlay(
                    Button(action: {
                        ShowThirdPage = false
                    }, label: {
                        Image(systemName: "xmark.circle.fill")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .padding()
                    }), alignment: .topTrailing)
            
        
    }
}

struct thirdview_Previews: PreviewProvider {
    static var previews: some View {
        thirdview(ShowThirdPage: .constant(true))
    }
}
