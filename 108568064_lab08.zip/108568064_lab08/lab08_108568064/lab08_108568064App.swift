//
//  lab08_108568064App.swift
//  lab08_108568064
//
//  Created by 林晏論 on 2021/5/12.
//

import SwiftUI

@main
struct lab08_108568064App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
