//
//  SongRow.swift
//  lab06_108568064
//
//  Created by 林晏論 on 2021/5/10.
//

import SwiftUI

struct SongRow: View {
    let song: Song
    var body: some View {
        
            HStack {
                Image(song.name)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 80, height: 80)
                    .clipped()
                VStack(alignment: .leading) {
                    Text(song.name)
                    Text(song.singer)
                    
                }
                Spacer()
                
            }
            
    }
}

struct SongRow_Previews: PreviewProvider {
    static var previews: some View {
        SongRow(song: Song(name: "擱淺", singer: "周杰倫"))
            .previewLayout(.sizeThatFits)
    }
}
