//
//  ContentView.swift
//  lab08_108568064
//
//  Created by 林晏論 on 2021/5/12.
//

import SwiftUI

struct ContentView: View {
    @State var fans = true
    @State private var picktime = Date()
    var roles = ["她沒在看我", "CHANGE", "WAIT", "太陽", "辣台妹"]
    @State private var selectedIndex = 0
    @State private var brightnessAmount: Double = 0
    @State private var ageoptions = 14
    @State private var tapping = ""
    @State private var showalert = false
    
    var body: some View {
        VStack (alignment: .trailing, spacing: 20)
        {
            Image("瘦子")
                .resizable()
                .scaledToFill()
                .frame(width: 400, height: 250)
                .brightness(brightnessAmount)
            
            Slider(value: $brightnessAmount, in: 0...1)
            
            VStack {
                HStack{
                    
                    Toggle(isOn: $fans, label: {
                        Text("是粉絲嗎？")
                        Text( fans ? "腦粉" : "單飛是狗")
                    })
                }
                
            }
            VStack {
                DatePicker("2021演唱會", selection : $picktime)
            }
            VStack{
                HStack{
                    Text("超想聽")
                    Picker(selection: $selectedIndex, label: Text("歌名"))
                    {
                        Text(roles[0]).tag(0)
                        Text(roles[1]).tag(1)
                        Text(roles[2]).tag(2)
                        Text(roles[3]).tag(3)
                        Text(roles[4]).tag(4)
                    }
                    
                }
                .frame(width: 400, height: 50)
                .clipped()
            }
            VStack{
                Stepper(value: $ageoptions, in: 18...32) {
                    Text("今年    \(ageoptions)     歲")
                }
            }
            VStack{
                TextField("想對瘦子說什麼", text:$tapping)
            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
            VStack{
                Button(action: {
                    showalert = true
                }, label: {
                    Text("送出表單")
                        .padding()
                })
                .alert(isPresented: $showalert) { () -> Alert in
                    let answer = ["瘦子", "頑童"].randomElement()!
                    return Alert(title: Text(answer))
                }
                
                
                
                
                
            }
            
            
            
            Spacer()
            
            
            
            
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
